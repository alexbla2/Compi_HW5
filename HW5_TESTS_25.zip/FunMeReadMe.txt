Hi everyone :)

I am writing this text to you, so it will be easy to understand how to run everything :)

To attemp to pass all tests at once:
./funMe

To attemp to pass level LEVEL_INDEX, type:
./funMe LEVEL_INDEX

For example: for level 0, use:
./funMe 0

There are 10 levels in total :)
So don't try to use LEVEL_INDEX that is not a number in the bounds [0,9] :)

PLEASE, PASS LEVEL 0 before you start with the rest... as NO HARM SHOULD BE DONE TO THE DESIRED HW3 RESULT... :)
--------------------------------------------
The folders:
Input: Where all tests appear :), in format .in
ExpectedCompile: The expected results to hw3 that is still required in hw5. It's LEVEL 0
ActualCompile: Your results to hw3 that is still required in hw5. It's LEVEL 0
ExpectedRuntime: The expected results to hw5, they should not report an error of hw3, therefore there will be a new .il file (MIPS source code) that then is ran with ./spim - file FILE.il to FILE.res
ActualRuntime: Your results to hw5, they should not report an error of hw3, therefore there will be a new .il file (MIPS source code) that then is ran with ./spim - file FILE.il to FILE.res
ActualMips: Your results to MIPS source code compilations, before the ./spim -file that is being passed on them :). In case you get an error to run ./spim (At some line), it means that your code is written illegally (Syntax of MIPS and not LOGICAL error)
--------------------------------------------

Please drink a lot of water and beer, it is highly recommend to relax and not feel pressured :)
The reinforcements will arrive :)
